package Control;

import Model.DataBase.TabelaAbastecimento;

public class BancoDados extends TabelaAbastecimento{

}
